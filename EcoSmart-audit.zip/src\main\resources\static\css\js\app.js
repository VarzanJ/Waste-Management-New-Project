
const searchInput = document.getElementById("searchInput");
const reportsTable = document.getElementById("reportsTable");

if (searchInput && reportsTable) {
    searchInput.addEventListener("input", function () {
        const searchText = this.value.toLowerCase();

        reportsTable.querySelectorAll("tbody tr").forEach(row => {
            const matches = row.innerText
                .toLowerCase()
                .includes(searchText);

            row.hidden = !matches;
        });
    });
}
