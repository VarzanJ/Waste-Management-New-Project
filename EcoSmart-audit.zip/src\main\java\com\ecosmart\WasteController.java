
package com.ecosmart;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
public class WasteController {

    private final WasteReportRepository repository;

    public WasteController(WasteReportRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/")
    public String dashboard(Model model) {
        List<WasteReport> reports = repository.findAll();

        double totalKg = reports.stream()
                .mapToDouble(WasteReport::getQuantityKg)
                .sum();

        long pending = reports.stream()
                .filter(r -> "Pending".equals(r.getStatus()))
                .count();

        long collected = reports.stream()
                .filter(r -> "Collected".equals(r.getStatus()))
                .count();

        Map<String, Long> categoryCounts = new LinkedHashMap<>();
        categoryCounts.put("Organic", 0L);
        categoryCounts.put("Plastic", 0L);
        categoryCounts.put("Paper", 0L);
        categoryCounts.put("Metal", 0L);
        categoryCounts.put("Other", 0L);

        for (WasteReport report : reports) {
            String type = report.getWasteType();
            if (categoryCounts.containsKey(type)) {
                categoryCounts.put(
                    type, categoryCounts.get(type) + 1
                );
            } else {
                categoryCounts.put(
                    "Other", categoryCounts.get("Other") + 1
                );
            }
        }

        model.addAttribute("reports", reports);
        model.addAttribute("totalReports", reports.size());
        model.addAttribute("totalKg", totalKg);
        model.addAttribute("pending", pending);
        model.addAttribute("collected", collected);
        model.addAttribute("categoryLabels",
                categoryCounts.keySet());
        model.addAttribute("categoryValues",
                categoryCounts.values());

        return "index";
    }

    @PostMapping("/reports")
    public String addReport(
            @RequestParam String wasteType,
            @RequestParam double quantityKg,
            @RequestParam String location,
            RedirectAttributes redirectAttributes) {

        if (quantityKg <= 0 || location.isBlank()) {
            redirectAttributes.addFlashAttribute(
                    "error", "Enter a valid quantity and location.");
            return "redirect:/";
        }

        WasteReport report = new WasteReport();
        report.setWasteType(wasteType);
        report.setQuantityKg(quantityKg);
        report.setLocation(location.trim());
        report.setStatus("Pending");

        repository.save(report);

        redirectAttributes.addFlashAttribute(
                "success", "Waste report added successfully!");

        return "redirect:/";
    }

    @PostMapping("/reports/{id}/status")
    public String updateStatus(
            @PathVariable Long id,
            @RequestParam String status,
            RedirectAttributes redirectAttributes) {

        if (!status.equals("Pending")
                && !status.equals("Collected")) {
            redirectAttributes.addFlashAttribute(
                    "error", "Invalid collection status.");
            return "redirect:/";
        }

        repository.findById(id).ifPresent(report -> {
            report.setStatus(status);
            repository.save(report);
        });

        redirectAttributes.addFlashAttribute(
                "success", "Collection status updated!");

        return "redirect:/";
    }

    @PostMapping("/reports/{id}/delete")
    public String deleteReport(
            @PathVariable Long id,
            RedirectAttributes redirectAttributes) {

        if (repository.existsById(id)) {
            repository.deleteById(id);
            redirectAttributes.addFlashAttribute(
                    "success", "Report deleted successfully!");
        }

        return "redirect:/";
    }
}
