
package com.ecosmart;

import org.springframework.data.jpa.repository.JpaRepository;

public interface WasteReportRepository
        extends JpaRepository<WasteReport, Long> {
}
